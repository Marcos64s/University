l1 = [1, 2, 3, 4, 5]
l2 = ['ola', 2.0, 1, True]

print(l1)
print(l2)
print(l1[0], ' ', l2[0])

print(l1[1:3])

l1[0] = 100
print('l1 after: ', l1)

l3 = l1
l3[1] = 200
print('l1 after l3 changes', l1)