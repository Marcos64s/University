def lerNumerosParaLista():
  l = []
  x = int(input('numero'))
  while x != 0: #and len(l) < 5:
    l.append(x)
    if len(l) == 5:
      break
      
    x = int(input('mais numeros'))
  
  return l
    
l2 = lerNumerosParaLista()
print(l2)