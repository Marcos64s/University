l = float(input('largura: '))
c = float(input('comprimento: '))

a = l * c
p = l * 2 + c * 2

print('area = ', a, ' perimetro = ', p)

