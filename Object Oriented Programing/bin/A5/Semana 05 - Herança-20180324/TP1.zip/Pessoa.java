package A05;

public class Pessoa {
	private int nif;
	private String nome;
	private int totalSono;
	private int totalCal;
	public Pessoa(int nif, String nome) {
		this.nif = nif;
		this.nome = nome;
		this.totalSono = 0;
		this.totalCal = 0;
		System.out.println("Foi criada uma pessoa!");
	}
	
	public int getTotalSono() {
		return totalSono;
	}

	public void setTotalSono(int totalSono) {
		this.totalSono = totalSono;
	}

	public int getTotalCal() {
		return totalCal;
	}

	public void setTotalCal(int totalCal) {
		this.totalCal = totalCal;
	}

	@Override
	public String toString() {
		return "Pessoa [nif=" + nif + ", nome=" + nome + " dormir " + totalSono + " comer " + totalCal + "]";
	}

	public int getNif() {
		return nif;
	}

	public void setNif(int nif) {
		this.nif = nif;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public void comer(int cal){
		this.totalCal += cal;
		System.out.println("Pessoa comeu");
	}
	
	public void dormir(int dur){
		this.totalSono += dur;
	}
	
	public final void souPessoa(){
		System.out.println("Sou uma pessoa");
	}
}
