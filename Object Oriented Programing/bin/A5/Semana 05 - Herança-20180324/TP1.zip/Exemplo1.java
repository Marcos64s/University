package A05;

public class Exemplo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Pessoa p = new Pessoa(1234556789, "joao");
		print(p);
		p.setNif(9999);
		p.setNome("joana");
		p.comer(1000);
		p.dormir(1);
		print(p);
		
		Aluno a = new Aluno(12345, "joao", 18132, "LEI");
		System.out.println(a);
		a.comer(200);
		a.dormir(10);
		a.estudar(1);
		print(a);
		
		Pessoa p2 = new Aluno(54321, "joao", 99999, "EGI");
		// p2.estudar(5); // não e possivel
		print(p2);
	}
	
	public static void print(Pessoa p){
		System.out.println(p);
	}

}
