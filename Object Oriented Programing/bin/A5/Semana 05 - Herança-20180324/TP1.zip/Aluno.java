package A05;

public class Aluno extends Pessoa {
	private int nMec;
	private String curso;
	private int totalEstudo;
	public final int ID = 1000; // constante

	public Aluno(int nif, String nome, int nmec, String curso) {
		super(nif, nome);
		this.nMec = nmec;
		this.curso = curso;
		this.totalEstudo = 0;
		System.out.println("Foi criado um Aluno!");
	}

	public int getnMec() {
		return nMec;
	}

	public void setnMec(int nMec) {
		this.nMec = nMec;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}
	
	public void comer(int cal){
		int tmp = super.getTotalCal();
		super.setTotalCal(tmp + 2 * cal);
		System.out.println("Aluno comeu");
	}

	public void estudar(int e){
		this.totalEstudo += e;
	}
	
	@Override
	public String toString() {
		return "Aluno [nMec=" + nMec + ", curso=" + curso + " estudo " + totalEstudo + ", Pessoa=" + super.toString() + "]";
	}

	/* public final void souPessoa(){
		System.out.println("Sou um Aluno");
	}*/ // Não e possivel
}
