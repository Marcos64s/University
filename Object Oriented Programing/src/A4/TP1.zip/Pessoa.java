package A04;

public class Pessoa {
	private int idade;
	private String nome;
	private int totalDormir;
	private int totalCal;
	private static int id = 100;
	private int myId;
	
	public Pessoa(int idade, String nome) {
		this.idade = idade;
		this.nome = nome;
		this.totalCal = 0;
		this.totalDormir = 0;
		this.myId = id;
		id++;
	}

	public Pessoa(){
		this.idade = 0;
		this.nome = "";
		this.totalCal = 0;
		this.totalDormir = 0;
		this.myId = id;
		id++;
	}

	public static int getId(){
		return id;
	}
	
	public int getIdade() {
		return this.idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@Override
	public String toString() {
		return "Pessoa " + this.myId + " com idade " + idade + " e nome " + nome + " dormiu " + this.totalDormir + " e comeu " + this.totalCal;
	}
	
	public void comer(int cal){
		this.totalCal += cal;
		System.out.println("Vai comer");
	}
	
	public void dormir(int duracao){
		this.totalDormir += duracao;
		System.out.println("Vai dormir");
	}

	public int getTotalCal() {
		return totalCal;
	}

	public void setTotalCal(int totalCal) {
		this.totalCal = totalCal;
	}

	public int getTotalDormir() {
		return totalDormir;
	}

	public void setTotalDormir(int totalDormir) {
		this.totalDormir = totalDormir;
	}
	
}
