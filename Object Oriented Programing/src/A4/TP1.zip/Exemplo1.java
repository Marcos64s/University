package A04;

public class Exemplo1 {

	public static void main(String[] args) {
		Pessoa p1 = new Pessoa(); // Construtor por defeito
		Pessoa p2 = new Pessoa(18, "Ana");
		
		System.out.println("idade 1 = " + p1.getIdade());
		System.out.println("idade 2 = " + p2.getIdade());
		p2.setIdade(23);
		System.out.println("idade 2 depois = " + p2.getIdade());
		
		System.out.println("toString do object: " + p2.toString());
		
		p1.comer(100);
		p2.comer(200);
		p1.dormir(90);
		p2.dormir(120);
		
		System.out.println(p1);
		System.out.println(p2);
		
		System.out.println("id = " + Pessoa.getId());

	}

}
