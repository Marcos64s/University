package A04;

public class Aluno {
	private String nome;
	private int nmec;
	private static int nAlunos = 0;
	
	public Aluno (){
		nome = "";
		nmec = 0;
		nAlunos++;
	}

	public Aluno (String n, int i){
		nome = n;
		nmec = i;
		nAlunos++;
	}
	
	public Aluno (String n){
		nome = n;
		nmec = 0;
		nAlunos++;
	}
	
	public String toString(){
		return "O aluno " + nome + " com o numero " + nmec + " nAlunos = " + nAlunos;
	}
	
	public void setNome(String n){
		nome = n;
	}
	
	public void setNmec(int i){
		nmec = i;
	}
	
	public String getNome(){
		return nome;
	}
		
	public int getNmec(){
		return nmec;
	}
}
