package A04;

public class E2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Aluno a1 = new Aluno("Joana", 12345);
		System.out.println("Antes: " + a1);
		a1.setNmec(99999);
		a1.setNome("joao");
		System.out.println("Depois: " + a1);
		
		System.out.println("O nome e " + a1.getNome() + " e o num e " + a1.getNmec());
	}

}
