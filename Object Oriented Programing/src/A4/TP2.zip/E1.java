package A04;
import java.util.Scanner;

public class E1 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		
		Aluno a1 = new Aluno();
		System.out.println(a1.toString());
		
		Aluno a2 = new Aluno("Ana", 18132);
		System.out.println(a2.toString());
		
		Aluno a3 = new Aluno("Joao");
		System.out.println(a3.toString());
		
		Aluno a4 = new Aluno("Maria", 80000);
		System.out.println(a4.toString());
		
		System.out.println("Novo aluno?");
		System.out.print("Nome?");
		String s = kb.nextLine();
		System.out.print("Num?");
		int i = kb.nextInt();
		Aluno a5 = new Aluno(s, i);
		System.out.println(a5.toString());
		
	}

}
