package A07;

public interface Desenhavel {
	public static final char simbolo = '*';
	public abstract void desenha();
}
