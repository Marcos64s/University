package A05TP2;

public class Aluno extends Pessoa {
	private int nmec;
	private String curso;

	public Aluno(int nif, String nome, int nmec, String curso) {
		super(nif, nome);
		this.nmec = nmec;
		this.curso = curso;
		System.out.println("Foi criado um aluno!");
	}

	public int getNmec() {
		return nmec;
	}

	public void setNmec(int nmec) {
		this.nmec = nmec;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	@Override
	public String toString() {
		return "Aluno [nmec=" + nmec + ", curso=" + curso + "," + super.toString() + "]";
	}

	
}
