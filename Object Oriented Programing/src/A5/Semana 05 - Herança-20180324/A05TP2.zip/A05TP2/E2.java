package A05TP2;

public class E2 {

	public static void main(String[] args) {
		Aluno a = new Aluno(12345, "joao", 999, "MIEGI");
		System.out.println("antes " + a);
		a.setNif(11111);
		System.out.println("depois " + a);
		Pessoa a2 = new Aluno(999, "maria", 111, "LEI");
		System.out.println(a2);
	}

}
