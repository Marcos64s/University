package A05TP2;

public class E1 {

	public static void main(String[] args) {
		Pessoa p1 = new Pessoa(12345, "joao");
		System.out.println(p1);

		Pessoa p2 = new Pessoa("joana");
		System.out.println(p2);
		
		Pessoa p3 = new Pessoa(999);
		System.out.println(p3);
		
		Pessoa p4 = new Pessoa();
		System.out.println("p4 a)" + p4.toString());
		p4.setNif(11111);
		p4.setNome("maria");
		System.out.println("p4 b)" + p4.toString());
		
		System.out.println("p3 de novo: " + p3);
		System.out.println("p1 de novo: " + p1);
	}

}
