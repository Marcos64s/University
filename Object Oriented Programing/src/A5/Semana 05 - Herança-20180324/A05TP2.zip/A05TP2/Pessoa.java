package A05TP2;

public class Pessoa {
	private int nif;
	private String nome;
	private static int count = 0;
	private int id;
	private final int qqCoisa = 200; // constante
	
	public Pessoa(int nif, String nome) {
		this.nif = nif;
		this.nome = nome;
		this.count++; // this.count = this.count + 1;
		this.id = count;
		System.out.println("Foi criada uma pessoa!");
	}
	
	public Pessoa(String nome) {
		this.nif = 0;
		this.nome = nome;
		this.count++;
		this.id = count;
	}
	
	public Pessoa(int nif) {
		this.nif = nif;
		this.nome = "Desconhecido";
		this.count++;
		this.id = count;
	}
	
	public Pessoa() {
		this.nif = 0;
		this.nome = "Desconhecido";
		this.count++;
		this.id = count;
	}

	public int getNif() {
		return this.nif;
	}

	public void setNif(int nif) {
		this.nif = nif;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String toString() {
		return "Pessoa n. " + this.id + " (em " + count + " pessoas) " +  " [nif=" + nif + ", nome=" + nome + "]";
	}
	
}
